# Minification is turned off for this project, so no extra rules are needed.
# If you enable isMinifyEnabled for release builds, kotlinx.serialization ships
# its own consumer rules, so it should keep working without changes here.
